<?php
    require_once("../Controller/cnx.php");


    function verifOldPassword($id, $oldMdp) {
        $isGoodPassword = false;
        $con = connexion();
        $sql = "SELECT * FROM user WHERE id='$id'";
        $req= $con->query($sql);
        $old = base64_decode($oldMdp);
        if($donnees = $req->fetch()){
            $password = $donnees['password'];
            if(password_verify($old, $password)){
                $isGoodPassword = true;
            }
        }
        
        return array("isGoodPassword" => $isGoodPassword);
    }

    function updateProfil($id, $nom, $prenom, $password){
        $con = connexion();
        $sqlDebut = "UPDATE user SET ";
        $sqlMilieu = "";
        $sqlFin = "WHERE id=$id";
        $options = [
            'cost' => 12,
        ];
        if($nom != ""){
            $sqlMilieu = $sqlMilieu." nom='$nom' ";
        }
        if($prenom != ""){
            $sqlMilieu = $sqlMilieu.", prenom='$prenom' ";
        }
        if($password != ""){
            $password = password_hash($password, PASSWORD_BCRYPT, $options);
            $sqlMilieu = $sqlMilieu.", password='$password' ";
        }
        $sql = $sqlDebut.$sqlMilieu.$sqlFin;
        $update = $con->exec($sql);
        $sql = "SELECT * FROM user where id='$id'";
        $req= $con->query($sql);
        if($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            $output[] = $donnees;
            return $output;
        }

    }

?>