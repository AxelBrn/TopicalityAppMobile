<?php
    require_once("../Controller/cnx.php");


    function getAllCategory() {
        $con = connexion();
        $sql = "SELECT * FROM categorie";
        $req= $con->query($sql);
        while($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            $output[] = $donnees;
        }
        return $output;
    }

?>