<?php
    require_once("../Controller/cnx.php");


    function getAllArticles() {
        $con = connexion();
        $sql = "SELECT article.*,user.nom as u_nom, user.prenom as u_prenom, categorie.libelle FROM article, user, categorie WHERE user.id=article.user_id and categorie.id=article.categorie_id ORDER BY article.datetime DESC";
        $req= $con->query($sql);
        while($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            $output[] = $donnees;
        }
        return $output;
    }

    function getArticle($id) {
        $con = connexion();
        $sql = "SELECT article.*,user.nom as u_nom, user.prenom as u_prenom, categorie.libelle FROM article, user, categorie where article.id='$id' and user.id=article.user_id and categorie.id=article.categorie_id ORDER BY article.datetime DESC";
        $req= $con->query($sql);
        if($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            $output[] = $donnees;
            return $output;
        }
        return [];
        
    }

    function getArticlesByCategory($idCat) {
        $con = connexion();
        $sql = "SELECT article.*,user.nom as u_nom, user.prenom as u_prenom, categorie.libelle FROM article, user, categorie WHERE categorie_id='$idCat' and user.id=article.user_id and categorie.id=article.categorie_id ORDER BY article.datetime DESC";
        $req= $con->query($sql);
        while($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            $output[] = $donnees;
        }
        return $output;
    }

    function getArticlesByUser($idUser) {
        $con = connexion();
        $sql = "SELECT article.*,user.nom as u_nom, user.prenom as u_prenom, categorie.libelle FROM article, user, categorie WHERE user_id='$idUser' and user.id=article.user_id and categorie.id=article.categorie_id ORDER BY article.datetime DESC";
        $req= $con->query($sql);
        if($donnees = $req->fetch(PDO::FETCH_ASSOC)){
        	while($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            	$output[] = $donnees;
        	}
		return $output;
	}
        return [];
    }

    function countYourArticles($idUser) {
        $con = connexion();
        $sql = "SELECT COUNT(id) as total FROM article WHERE user_id='$idUser'";
        $req= $con->query($sql);
        while($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            $output[] = $donnees;
        }
        return $output;
    }

    function addArticle($image, $file_type, $is_image, $titre, $sousTitre, $contenu, $source, $user, $categ) {
        $path = "";
        $con = connexion();
        $date = (new \DateTime())->format('Y-m-d H:i:s');
        $data = array('image' => null );
        $sqlChamps= "article(user_id, categorie_id, nom, contenu, source, datetime, is_active";
        $sqlValues= "($user, $categ, '$titre', '$contenu', '$source', '$date', 1";
        $image = null;
        if($is_image) {
            $data['image'] = time() . '.' . $file_type;
            $path = '../../Topicality/public/uploads/images/'.  $data['image'];
            if(move_uploaded_file($_FILES['file']['tmp_name'], $path)){
                $image = $data['image'];
                $sqlChamps = $sqlChamps.", image";
                $sqlValues = $sqlValues.", '$image'";
            }
        }
        if($sousTitre == ""){
            $sousTitre= null;
            $sqlChamps = $sqlChamps.")";
            $sqlValues = $sqlValues.")";
        }else{
            $sqlChamps = $sqlChamps.", sous_titre)";
            $sqlValues = $sqlValues.", '$sousTitre')";
        }
        $sql = "INSERT INTO ".$sqlChamps." VALUES ".$sqlValues;
        $req= $con->exec($sql);
        return array('publish' => true);
    }

    function updateArticle($image, $file_type, $is_image, $titre, $sousTitre, $contenu, $source, $categ, $idArticle) {
        $path = "";
        $con = connexion();
        $data = array('image' => null );
        $sqlDebut = "UPDATE article SET categorie_id=$categ , nom='$titre', source='$source', contenu='$contenu'";
        $sqlFin = " WHERE id=$idArticle";
        $image = null;
        if($is_image) {
            $data['image'] = time() . '.' . $file_type;
            $path = '../../Topicality/public/uploads/images/'.  $data['image'];
            if(move_uploaded_file($_FILES['file']['tmp_name'], $path)){
                $image = $data['image'];
                $sqlDebut = $sqlDebut.", image='$image'";
            }
        }
        if($sousTitre != "null"){
            $sqlDebut = $sqlDebut.", sous_titre='$sousTitre'";
        }
        else{
            $sqlDebut = $sqlDebut.", sous_titre = null";
        }
        $sql = $sqlDebut.$sqlFin;
        $req= $con->exec($sql);
        return array('update' => true);
    }

    function deleteArticle($id) {
        $con = connexion();
        $sql = "DELETE FROM article WHERE id=$id";
        $req = $con->exec($sql);
        return array("exec" -> true);
    }

?>