<?php
    require_once("../Controller/cnx.php");


    function getAuthentification($mail, $password) {
        $con = connexion();
        $sql = "SELECT * FROM user where email='$mail'";
        $req= $con->query($sql);
        if($donnees = $req->fetch(PDO::FETCH_ASSOC)){
            $mdp = base64_decode($password);
            if(password_verify($mdp, $donnees['password'])){
                $output[] = $donnees;
                return $output;
            }
        }
        return [];
    }

?>