
<?php
function connexion(){
    try {
        $cnx = new PDO('mysql:host=localhost;dbname=topicality;charset=utf8', 'root', '');
    
    } catch (PDOException $e) {
        print "Erreur !: " . $e->getMessage() . "<br/>";
        die();
    }
    return $cnx;
}

?>