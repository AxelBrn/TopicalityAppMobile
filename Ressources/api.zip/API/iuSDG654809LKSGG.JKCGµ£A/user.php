<?php

header('content-type:application/json');
require_once("../Repository/userRepository.php");

    if(isset($_GET['id']) && isset($_GET['pw'])) {
        $id = $_GET['id'];
        $password = $_GET['pw'];
        echo json_encode(verifOldPassword($id, $password));
    }

    if(isset($_GET['idUser'])){
        $idUser = $_GET['idUser'];
        $password= "";
        if(isset($_GET['pw'])){
            $tempPw = $_GET['pw'];
            if($tempPw != ""){
                $password = base64_decode($_GET['pw']);
            }
        }
        
        $nom = $_GET['nom'];
        $prenom = $_GET['prenom'];
        echo json_encode(updateProfil($idUser, $nom, $prenom, $password));
    }

?>