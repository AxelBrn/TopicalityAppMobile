<?php

header('content-type:application/json');
require_once("../Repository/authentificationRepository.php");

    if(isset($_POST['userMail']) && isset($_POST['pw'])) {
        $mail = $_POST['userMail'];
        $password = $_POST['pw'];
        echo json_encode(getAuthentification($mail, $password));
    }

?>