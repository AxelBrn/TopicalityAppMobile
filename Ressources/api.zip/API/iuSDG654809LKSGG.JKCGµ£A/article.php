<?php

header('content-type:application/json');
header('Access-Control-Allow-Origin: *');
require_once("../Repository/articlesRepository.php");

    if(isset($_GET['id'])){
        $id = $_GET['id'];
        echo json_encode(getArticle($id));
    }
    else if(isset($_GET['idCat'])){
        $idCat = $_GET['idCat'];
        echo json_encode(getArticlesByCategory($idCat));
    }
    else if(isset($_GET['idUser'])){
        $idUser = $_GET['idUser'];
        echo json_encode(getArticlesByUser($idUser));
    }
    else if(isset($_GET['countById'])){
        $idUser = $_GET['countById'];
        echo json_encode(countYourArticles($idUser));
    }
    else if(isset($_POST['insert'])){
        if(isset($_POST['haveImage'])){
            $verif = $_POST['haveImage'];
            if($verif== "oui"){
                $target_file = basename($_FILES['file']['name']);
                $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
                $is_image = getimagesize($_FILES['file']['tmp_name']);
            }else{
                $target_file = "";
                $file_type= "";
                $is_image = false;
            }
        }
        $user = $_POST['user'];
        $categ = $_POST['categorie'];
        $titre = addslashes($_POST['titre']);
        $contenu = addslashes($_POST['contenu']);
        $source = $_POST['source'];
        $sousTitre = "";
        if(isset($_POST['sousTitre'])){
            $sousTitre = addslashes($_POST['sousTitre']);
        }
        echo json_encode(addArticle($target_file, $file_type, $is_image, $titre, $sousTitre, $contenu, $source, $user, $categ));
    }
    else if(isset($_POST['update'])){
        if(isset($_POST['haveImage'])){
            $verif = $_POST['haveImage'];
            if($verif== "oui"){
                $target_file = basename($_FILES['file']['name']);
                $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
                $is_image = getimagesize($_FILES['file']['tmp_name']);
            }else{
                $target_file = "";
                $file_type= "";
                $is_image = false;
            }
        }
        $idArticle = $_POST['idArticle'];
        $categ = $_POST['categorie'];
        $titre = addslashes($_POST['titre']);
        $contenu = addslashes($_POST['contenu']);
        $source = $_POST['source'];
        $sousTitre = "";
        if(isset($_POST['sousTitre'])){
            $sousTitre = addslashes($_POST['sousTitre']);
        }
        echo json_encode(updateArticle($target_file, $file_type, $is_image, $titre, $sousTitre, $contenu, $source, $categ, $idArticle));
    }
    else if(isset($_POST['delete'])){
        $idArticle = $_POST['id'];
        echo json_encode(deleteArticle($idArticle));
    }
    else{
        echo json_encode(getAllArticles());
    }
    

?>