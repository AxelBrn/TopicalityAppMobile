<?php
header('Access-Control-Allow-Origin: *');
header('content-type:application/json');

$data = array('image' => null );

if(isset($_POST['submit'])){
    $target_file = basename($_FILES['file']['name']);
    $file_type = pathinfo($target_file, PATHINFO_EXTENSION);
    $is_image = getimagesize($_FILES['file']['tmp_name']);
    if($is_image) {
        $data['image'] = time() . '.' . $file_type;
        $path = '../../Topicality/public/uploads/images/'.  $data['image'];
        if(move_uploaded_file($_FILES['file']['tmp_name'], $path)){
            echo json_encode($data);
        }else{
            echo json_encode(array('image' => null));
        }
    }else{
        echo json_encode($data);
    }
}


?>