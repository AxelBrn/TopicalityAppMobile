<?php

header('content-type:application/json');
require_once("../Repository/categoryRepository.php");


    echo json_encode(getAllCategory());


?>